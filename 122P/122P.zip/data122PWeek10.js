var diggingDeeperVideos = [{
"title":" Adversity and the Divine Purpose of Mortality - General Conference April 1989",
"speaker":"  Ronald E. Poelman",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/ronald-e-poelman.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_7y1huk1s&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=529&flashvars[mediaProxy.mediaPlayFrom]=439&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Tithing",
"speaker":"  Ronald E. Poelman",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/ronald-e-poelman.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_twok5t7e&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=334&flashvars[mediaProxy.mediaPlayFrom]=202&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" The Law of Tithing - General Conference October 2006",
"speaker":"  Daniel L. Johnson",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/daniel-l-johnson.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_pfwjvczr&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=468&flashvars[mediaProxy.mediaPlayFrom]=361&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Tithing - General Conference April 1994",
"speaker":"  Dallin H. Oaks",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/dallin-h-oaks-5.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_t9rnn96v&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=437&flashvars[mediaProxy.mediaPlayFrom]=370&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Be and Do to Become",
"speaker":" The Clarks",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/golden-plates.jpg",
"frameURL":"https://content.byui.edu/file/bed1a9a0-2ca1-49ae-a967-246d1efea7ab/1/_mypages/001eeff9-bdf1-41fc-8aa1-10403ea82558/page.html"
},
{
"title":" They Taught and Did Minister One to Another - General Conference April 1986",
"speaker":"  James M. Paramore",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/james-m-paramore.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_5necfx2v&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=212&flashvars[mediaProxy.mediaPlayFrom]=29&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Listen to Learn",
"speaker":"  Russell M. Nelson",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/russell-m-nelson.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_cjbjeygg&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=635&flashvars[mediaProxy.mediaPlayFrom]=524&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Becoming More Powerful Priesthood Holders - General Conference November 2009",
"speaker":"  Walter F. Gonzalez",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/walter-f-gonzalez.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_o4wi6bqg&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=317&flashvars[mediaProxy.mediaPlayFrom]=198&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
}];
var diggingDeeperVideos = [{
"title":" Receiving a Testimony of the Restored Gosepl of Jesus Christ - General Conference October 2003",
"speaker":"  Robert D. Hales",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/robert-d-hales-3.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_afjjtmq9&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=977&flashvars[mediaProxy.mediaPlayFrom]=753&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Personal Revelation - General Conference October 2007",
"speaker":"  Robert D. Hales",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/robert-d-hales.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_6hyom9e8&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=656&flashvars[mediaProxy.mediaPlayFrom]=176&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" An Easiness and Willingness to Believe - General Conference October 2009",
"speaker":"  Michael T. Ringwood",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/michael-t-ringwood.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_u43kxalp&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=185&flashvars[mediaProxy.mediaPlayFrom]=2&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Be of Good Cheer - General Conference October 1982",
"speaker":"  Neal A. Maxwell",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/neal-a-maxwell.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_2vaa9705&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=985&flashvars[mediaProxy.mediaPlayFrom]=780&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Aligned With the Truth",
"speaker":" Brother Robert Bear",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/golden-plates.jpg",
"frameURL":"https://content.byui.edu/file/c05390bc-05fa-430f-9b3b-76ad212838b3/1/_mypages/0cb3ac5c-e9fa-43bf-b5a4-ed7afa6f2662/page.html"
},
{
"title":" Repent… That I May Heal You - General Conference October 2009",
"speaker":"  Neil L. Andersen",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/neil-l-andersen.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_a51pxd4y&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=597&flashvars[mediaProxy.mediaPlayFrom]=153&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" As A Child - General Conference April 2006",
"speaker":"  Henry B. Eyring",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/henry-b-eyring.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_ynftoefw&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=121&flashvars[mediaProxy.mediaPlayFrom]=4&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Full Conversion Brings Happiness - General Conference April 2002",
"speaker":"  Richard G. Scott",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/richard-g-scott.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_gzsw86as&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=920&flashvars[mediaProxy.mediaPlayFrom]=808&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
}];
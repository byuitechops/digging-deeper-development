var diggingDeeperVideos = [{
"title":" Personal Purity - October 1998",
"speaker":"  Jeffrey R. Holland",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/jeffrey-r-holland.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_y43jtdi1&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=1062&flashvars[mediaProxy.mediaPlayFrom]=1005&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" The Touch of the Master’s Hand - April 2001",
"speaker":"   Boyd K. Packer",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/boyd-k-packer-3.jpg",
"frameURL":"https://cdnapisec.kaltura.com/html5/html5lib/v2.40/mwEmbedFrame.php/p/1157612/uiconf_id/29018071/entry_id/0_yus6tm6k?wid=_1157612&iframeembed=true&playerId=kaltura_player_1453575767&entry_id=0_yus6tm6k&flashvars[streamer%20Type]=auto"
},
{
"title":" I Will Remember Your Sins No More - April 2006",
"speaker":"  Boyd K. Packer ",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/boyd-k-packer-2.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_bbbbattj&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=78&flashvars[mediaProxy.mediaPlayFrom]=12&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Pornography - April 2005",
"speaker":"  Dallin H. Oaks",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/dallin-h-oaks-2.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_xsuzwtqb&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=1053&flashvars[mediaProxy.mediaPlayFrom]=934&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Being Restored to Righteousness",
"speaker":" Brother Todd Hammond",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/golden-plates.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_uaproscc&flashvars[streamerType]=auto& amp;&wid=0_7quonwkk"
},
{
"title":" Come What May and Love It",
"speaker":" Mormon Message -  Joseph B. Wirthlin",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/joseph-b-wirthlin.jpg",
"frameURL":"https://www.youtube.com/embed/tVNYhcYEwIE?rel=0"
},
{
"title":" The Power of Righteousness - October 1998",
"speaker":"  Richard G. Scott",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/richard-g-scott.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_dylhdik9&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=856&flashvars[mediaProxy.mediaPlayFrom]=776&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
},
{
"title":" Bring Up a Child in the Way He Should Go - October 1993",
"speaker":"  Gordon B. Hinckley",
"imageURL":"https://content.byui.edu/integ/gen/7a262da4-897d-47fc-a0ac-4b07a1f1e964/0/gordon-b-hinckley.jpg",
"frameURL":"https://cdnapisec.kaltura.com/p/1157612/sp/115761200/embedIframeJs/uiconf_id/29018071/partner_id/1157612?iframeembed=true&playerId=kaltura_player&entry_id=0_48pwol1f&flashvars[streamerType]=auto&flashvars[mediaProxy.mediaPlayTo]=759&flashvars[mediaProxy.mediaPlayFrom]=580&flashvars[localizationCode]=en&flashvars[leadWithHTML5]=true&flashvars[sideBarContainer.plugin]=true&flashvars[sideBarContainer.position]=left&flashvars[sideBarContainer.clickToClose]=true&flashvars[chapters.plugin]=true&flashvars[chapters.layout]=vertical&flashvars[chapters.thumbnailRotator]=false&flashvars[streamSelector.plugin]=true&flashvars[EmbedPlayer.SpinnerTarget]=videoHolder&flashvars[dualScreen.plugin]=true&&wid=0_oqubdp28"
}];